<?php
/**
 * @see WC_AJAX::do_wc_ajax()
 */
namespace TripleA_Cryptocurrency_Payment_Gateway_for_WooCommerce\WooCommerce;

/**
 * Class AJAX
 *
 * @package TripleA_Cryptocurrency_Payment_Gateway_for_WooCommerce\WooCommerce
 */
class AJAX {

}
