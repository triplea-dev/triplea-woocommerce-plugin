<?php
/**
 * Silence is golden.
 *
 * @package    TripleA_Cryptocurrency_Payment_Gateway_for_WooCommerce
 */

die();
